=== Plugin Name ===
Contributors: Jimtrim
Tags: instagram, tag, hashtag, view, viewer
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Stable tag: 0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

HashViewer is a plugin for browsing Instagram pictures base on hashtags within the admin panel.

== Description ==

HashViewer has the hope for making Instagram competitions a breeze. Viewing, rating, and interacting with the participants of your competition right from your websites admin panel makes for a more streamlined workflow

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the `hash-viewer/` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Start using HashViewer in the media 

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. This screen shot shows the admin panel, with a a search active

== Changelog ==

= 0.2 =
* Styles added to the admin panel

= 0.1 =
* Imported logic from previous project [HashViewer](www.hashviewer.net "HashViewer")